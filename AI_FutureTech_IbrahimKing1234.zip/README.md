
# AI_FutureTech_IbrahimKing1234
Portfolio website: AI & Future Tech by Ibrahim King 1234

## Contents
- index.html
- style.css
- images/ (placeholder images used as filenames)

## How to publish on GitHub Pages
1. Create a new repository on GitHub (e.g., `AI_FutureTech_IbrahimKing1234`).
2. Upload all files from this ZIP to the repository (commit to main branch).
3. In the repository Settings -> Pages, set the source to `main` branch, `/ (root)` and save.
4. Your site will be live at: https://<your-github-username>.github.io/AI_FutureTech_IbrahimKing1234/

## Notes
- Images in `images/` folder are included as placeholders. Replace with your own images if you like.
- Contact form is a demo (client-side); to receive messages, integrate with an email service or Netlify Forms / Formspree.
